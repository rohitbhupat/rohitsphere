import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const sesClient = new SESClient({ region: "ap-south-1" }); // change region

export const handler = async (event) => {
    try {
        console.log("Event:", event);

        // If triggered via API Gateway HTTP API with JSON body
        const body = JSON.parse(event.body);

        const { name, email, message } = body;

        if (!name || !email || !message) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: "Missing required fields" }),
            };
        }

        // Email parameters
        const params = {
            Destination: {
                ToAddresses: ["rohitbhupat300@gmail.com"], // your verified email
            },
            Message: {
                Body: {
                    Text: {
                        Data: `You got a new message from your portfolio:\n\nName: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
                    },
                },
                Subject: { Data: "New Portfolio Contact Form Submission" },
            },
            Source: "rohitbhupat300@gmail.com", // must be verified in SES
            ReplyToAddresses: [email],
        };

        // Send email
        const command = new SendEmailCommand(params);
        await sesClient.send(command);

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // CORS
                "Access-Control-Allow-Methods": "OPTIONS,POST",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ success: true, message: "Email sent successfully!" }),
        };
    } catch (error) {
        console.error("Error sending email:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Failed to send email" }),
        };
    }
};
